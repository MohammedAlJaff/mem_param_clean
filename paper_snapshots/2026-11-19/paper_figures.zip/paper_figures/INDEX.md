# Generated paper figures

Source: [tracked catalog](../../plotting/figure_catalog.json). M1-M6 identify the main items; A1-A5 identify appendix groups.

Only generated items appear here. See [paper review list](README.txt) for the planned manuscript items. Approval applies only to an explicitly approved build. Legacy PDFs have no build receipt; rebuild to establish provenance.

M6 is a notebook export with its source linked below; it has no catalog build receipt.

| ID | Variant | Placement | Review | Build | PDF | Code |
| --- | --- | --- | --- | --- | --- | --- |
| A1 | unet-dual-axis | appendix | draft | stale [25d0461836dd](versions/A1/25d0461836dd/A1.pdf) | [PDF](A1.pdf) | [renderer](../../plotting/celeba32_3x3/plot_f_mem_grid.py) |
| A1_DIT | dit-dual-axis | appendix | draft | stale [c193bb3f5dcb](versions/A1_DIT/c193bb3f5dcb/A1_DIT.pdf) | [PDF](A1_DIT.pdf) | [renderer](../../plotting/celeba32_3x3/plot_f_mem_grid.py) |
| A4 | diagonal-and-weighted-velocity | appendix | draft | current [601dad7c7933](versions/A4/601dad7c7933/A4.pdf) | [PDF](A4.pdf) | [renderer](../../plotting/celeba32_3x3/compare_weighted_velocity.py) |
| M2 | unet-trajectories-summary | main | needs-review | stale [43d9a790863d](versions/M2/43d9a790863d/M2.pdf) | [PDF](M2.pdf) | [renderer](../../plotting/plot_diagonal_summary.py) |
| M5 | workshop-reproduction | main | draft | stale [686001f79577](versions/M5/686001f79577/M5.pdf) | [PDF](M5.pdf) | [renderer](../../plotting/plot_workshop_timescales.py) |
| A3_DIT | dit-timescales | appendix | draft | stale [68d2ee0590c5](versions/A3_DIT/68d2ee0590c5/A3_DIT.pdf) | [PDF](A3_DIT.pdf) | [renderer](../../plotting/plot_diagonal_timescales.py) |
| M3 | split-n-matrices | main | draft | stale [9ad16db1854a](versions/M3/9ad16db1854a/M3.pdf) | [PDF](M3.pdf) | [renderer](../../plotting/celeba32_3x3/plot_best_fid_matrices.py) |
| M3-SSCD | split-n-sscd | unassigned | draft | stale [b31554d75753](versions/M3-SSCD/b31554d75753/M3-SSCD.pdf) | [PDF](M3-SSCD.pdf) | [renderer](../../plotting/celeba32_3x3/plot_best_fid_matrices.py) |
| M3-DIT | split-n-dit | unassigned | draft | stale [bce5c65ba5f4](versions/M3-DIT/bce5c65ba5f4/M3-DIT.pdf) | [PDF](M3-DIT.pdf) | [renderer](../../plotting/celeba32_3x3/plot_best_fid_matrices.py) |
| M4 | pixel-and-feature-rows | main | needs-review | stale [515a0307ff37](versions/M4/515a0307ff37/M4.pdf) | [PDF](M4.pdf) | [renderer](../../plotting/plot_robustness_table.py) |
| A2 | unet-representation | appendix | draft | stale [16680788af83](versions/A2/16680788af83/A2.pdf) | [PDF](A2.pdf) | [renderer](../../plotting/plot_memorization_sensitivity.py) |
| A5 | unet-threshold | appendix | draft | stale [f9bcf9a596cc](versions/A5/f9bcf9a596cc/A5.pdf) | [PDF](A5.pdf) | [renderer](../../plotting/plot_memorization_sensitivity.py) |
| A5_TRAJECTORIES | unet-threshold-trajectories | appendix | draft | stale [8a701abbeb2f](versions/A5_TRAJECTORIES/8a701abbeb2f/A5_TRAJECTORIES.pdf) | [PDF](A5_TRAJECTORIES.pdf) | [renderer](../../plotting/plot_memorization_sensitivity.py) |
| M6 | linear-rfn-random-init | main | draft | notebook export | [PDF](M6.pdf) | [notebook](../../notebooks/theory/theory_notebook_from_claude.ipynb) |
