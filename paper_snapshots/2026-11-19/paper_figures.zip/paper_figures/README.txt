CURRENT PAPER FIGURES

Use M1-M6 for the main items and A1-A5 for the appendix groups.
Specification: ../../docs/paper_figure_plan.txt

[x] M1  Setup schematic                  Done; handmade by the authors
[x] M2  Diagonal dynamics and summaries  Approved: M2.pdf
M3  Prediction/loss grid              Draft ready: M3.pdf
M3-SSCD  U-Net SSCD variant           Draft ready: M3-SSCD.pdf
M3-DIT   Small-DiT raw-pixel variant  Draft ready: M3-DIT.pdf
[x] M4  Robustness table                 Approved: M4.pdf and M4.tex
M5  Original workshop timescales      Selected artwork; revised caption: M5.pdf
M6  Linear/RFN initialization gaps   Notebook export: M6.pdf and M6.png
A1  Complete trajectories            Joint grids ready: A1.pdf (U-Net), A1_DIT.pdf
A2  Representation comparison        First draft ready: A2.pdf
A3  Extended timescales/sensitivity  A3_DIT.pdf; A3_UNET registered; sensitivity planned
A4  Diagonal and weighting controls  F07-style draft ready: A4.pdf
A5  Threshold sensitivity            Best-FID: A5.pdf; trajectories: A5_TRAJECTORIES.pdf

The conversion table is M1's companion: M1_CONVERSIONS.
M5 now reproduces the selected workshop Figure 4 with a revised caption. M4
is the robustness table; M6 is theory. A3 contains current-data timescales.
Suffixes identify variants within a group, such as A3_DIT.

M6 is saved by the "Combined paper figure: M6" cell in
../../notebooks/theory/theory_notebook_from_claude.ipynb. It writes directly
to this folder. This notebook export is a draft without a catalog build receipt.

Work on one chosen item or an explicitly chosen small group at a time.
Keep the accepted layouts and scientific contracts. M5 explicitly preserves
the workshop artwork, rho=0.5, first-1% onset, SE, and capped unobserved times.
New main results use raw pixels at rho=0.3; appendix variants state their rules.

From the repository root:
  conda run -n memcompgen python plotting/figures.py M2
  conda run -n memcompgen python plotting/figures.py --show M2

APPROVED: M2
PDF: M2.pdf
Caption: M2.caption.txt
Build: 43d9a790863d
The naming change preserves the preceding draft's pixels. The 48 summary
means/SDs were checked against the existing raw-pixel summaries.

CURRENT REVIEW: M3
PDF: M3.pdf
Caption: M3.caption.txt
Build: 9ad16db1854a
Uses the paper PDF's wide two-matrix layout and coloring, with raw-pixel
memorization at rho=0.3 and mean +/- sample SD. Width matches M2: 8.8 inches.
All 18 cells were checked independently against the source CSV records.

REQUESTED M3 VARIANTS (DRAFTS; PLACEMENT UNASSIGNED)
M3-SSCD.pdf: U-Net, calibrated SSCD alpha=0.01, seeds 0/1/2, sample SD.
M3-DIT.pdf: Small-DiT, raw pixels rho=0.3, seed 0 only; no across-seed SD.
Both retain N=512/2048, M3's colors/layout, and M2's 8.8-inch width.
Each pairs memorization with that seed's own best-FID checkpoint.
Build only this selected pair with:
  conda run -n memcompgen python plotting/figures.py M3-SSCD M3-DIT
Read the matching .caption.txt and .build.json for methods and exact provenance.
The headline raw-pixel M3 and approved M2 have not been regenerated.

APPROVED: M4 / MANUSCRIPT TABLE 2
PDF: M4.pdf (preview; 6.75-inch table width with 0.12-inch margins)
LaTeX: M4.tex (metric column plus four dataset columns; native manuscript width)
Captions: M4.caption.txt and M4.caption.tex
Build: 515a0307ff37
N=2048; four dataset/model columns with x/x, epsilon/epsilon, v/v triplets.
Each column stacks raw-pixel f_mem (rho=0.3), calibrated feature f_mem
(alpha=0.01), and paired best quality. The caption explains this order.
The fragment inherits manuscript fonts and the original tablehead/tablerow/qgray
colors. It keeps native small text, arraystretch=1.55, default column padding,
and plain makecell line breaks. Slash spacing also matches the original.
The added Metric column labels raw pixels, features, and best quality.
Both memorization rows use the same per-seed best-quality
checkpoint. Feature representations are explained in the caption. Values use
three-seed means, except Small-DiT: seed 0. SDs are omitted from this compact
display; the previous SD version remains in versions/M4/fa972b2246c8/.
All 30 selected seed checkpoints and 36 displayed readouts were independently
checked against the exports. Build only M4 with:
  conda run -n memcompgen python plotting/figures.py M4

CURRENT REVIEW: M5 / ORIGINAL WORKSHOP TIMESCALES
PDF: M5.pdf; build 686001f79577.
Captions: M5.caption.txt and M5.caption.tex.
Original CelebA32 grayscale U-Net Figure 4, seven sizes N=256 through 16384.
The revised caption explains rho=0.5, first-1% onset, SE over three seeds,
and assignment of unobserved onsets to the final checkpoint at 1m. The
plateaus and corresponding gaps include capped observations.
Portable source: ../../plotting/references/workshop_figure4.pdf and .txt.
The former current-data M5 is intact under versions/M5/1632be7bf6a4/.
Its renderer is registered as A3_UNET, paired with A3_DIT (existing build
68d2ee0590c5): current rho=0.3, sustained 5% onset, SD, and explicit bounds.
  conda run -n memcompgen python plotting/figures.py M5

FIRST APPENDIX DRAFTS: A2 AND A5
A2.pdf (16680788af83): pixels/SSCD/LPIPS/DINOv2, common alpha=0.01.
A5.pdf (f9bcf9a596cc): fixed raw-pixel rho=0.3/0.5/0.7.
Both use CelebA32 U-Net, four N panels, the same 36 per-seed best-FID
checkpoints, and mean +/- sample SD. Captions distinguish calibrated pixels
from fixed-rho pixels and aggregate rates from per-image agreement.
The fixed-rho mean ordering persists, but representation ordering can change;
DINOv2 at N=1024 gives lower mean for x/x than epsilon/epsilon. Do not claim
universal agreement or statistical significance from these plots.
The scalar bundle cannot supply per-image overlap. Calibrated-alpha sweeps,
other datasets, and sensitivity to the onset cutoff remain planned.
  conda run -n memcompgen python plotting/figures.py A2 A5
Expected outputs: A2/A5 PDF, SVG, captions, receipts and source archives.
The command was executed locally in memcompgen. All 252 paired readouts and
84 means/sample SDs were checked independently against the input CSVs.

INDEX.md links generated items. versions/ preserves exact earlier builds,
including the initial draft under its old name. Earlier outputs in ../figures/
remain intact. Old command names remain compatibility aliases only; current
commands, files, and discussion use the M/A names above.

CAPTION ALTERNATIVES FOR A2 AND A5 (2026-10-07)
Each figure has .caption.short.txt/.tex and .caption.appendix.txt/.tex.
The fuller appendix versions give definitions, reading instructions, results,
and limits of interpretation. They refer to A2 build 16680788af83 and A5
build f9bcf9a596cc. These are review alternatives; the current caption aliases
and generated figures have not been replaced.

CURRENT REVIEW: A5_TRAJECTORIES
PDF/SVG: A5_TRAJECTORIES.pdf/.svg; build 8a701abbeb2f (shortened caption).
Caption: A5_TRAJECTORIES.caption.txt and .caption.tex.
Workshop-style 3x3 grid on current CelebA32 U-Net data: parameterization
rows (epsilon/epsilon, v/v, x/x), threshold columns (rho=0.3/0.5/0.7).
Four N sizes use the canonical target colors, increasingly light shades and
solid/dashed/dash-dot/dotted lines. Mean +/- sample SD over three seeds.
All 72 saved checkpoints enter the summaries; the 71 positive steps are
eligible for log-axis display. Zero means are omitted, not replaced with a
positive floor. Small markers retain isolated positive points. SD bands
are clipped to display bounds. The current A5 best-FID summary is preserved.
  conda run -n memcompgen python plotting/figures.py A5_TRAJECTORIES
Executed locally in memcompgen; writes PDF/SVG, captions, and a build receipt.
Source: ../../plotting/plot_memorization_sensitivity.py (render_trajectories).
Checked all 7776 scalar inputs and 2592 means/sample SDs independently.

CURRENT REVIEW: A1 AND A1_DIT
A1.pdf/.svg: CelebA32 grayscale U-Net, build 25d0461836dd.
A1_DIT.pdf/.svg: CelebA32 grayscale Small-DiT, build c193bb3f5dcb.
Each full prediction/loss grid overlays N=512/1024/2048/4096 per panel.
Prediction colors retain red/blue/green. Four explicit shades per target
run from darkest at N=512 to lightest at N=4096, shown by long legend lines.
Neither FID nor F_mem curves have markers.
FID is dotted on the left; raw-pixel F_mem at rho=0.3 is solid on the right.
Both use linear metric axes and log training steps with identical ranges.
U-Net has three-seed mean/sample SD; DiT shows seed 0 without SD bands.
Captions: A1.caption.txt/.tex and A1_DIT.caption.txt/.tex.
  conda run -n memcompgen python plotting/figures.py A1 A1_DIT
Executed in memcompgen. Checked all 20736 source values and 10368 summaries;
both metrics have 72 matching checkpoints per run (71 positive steps plotted).
Generator: ../../plotting/celeba32_3x3/plot_f_mem_grid.py (render).

CURRENT REVIEW: A4 DIAGONAL TARGETS AND VELOCITY WEIGHTS
PDF/SVG: A4.pdf/.svg; build 601dad7c7933.
Caption: A4.caption.txt/.tex; preview: previews/A4__601dad7c7933.png.
The researcher selected the original F07 comparison. Columns N=512/2048;
FID above raw-pixel f_mem at rho=0.3. Solid red/blue/green: x/x, eps/eps,
v/v. Dashed purple/dotted orange: native-v/v weights (1-t)^2 and t^2.
The shared two-column legend sits above the panels and names x-equivalent
and epsilon-equivalent. Means and sample SD over three seeds; 71 positive
checkpoints, no markers. The repeated unit controls count once. Previous
matched-row drafts are archived as fb007ce22e62 and c5e7ad733499.
Build only this item with:
  conda run -n memcompgen python plotting/figures.py A4

OVERLEAF INCLUDE FILES
results_figures.tex contains M2--M6; M4 stays a native table and M6 uses one
column. appendix_figures.tex contains the seven current appendix exports.
Both use figures/ PDF paths and include captions plus cross-reference labels.
Optional M3-SSCD/M3-DIT blocks are commented at the end of the appendix file.
overleaf_figures.zip contains both fragments, 13 PDFs under figures/, and
upload/preamble instructions. Use \input{results_figures} in the results
section and \input{appendix_figures} after the existing appendix heading.
Compiled and visually checked in a local article wrapper; final float
placement follows the Overleaf manuscript class and surrounding text.
